﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace PcMan
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        //teste
        //teste2
        
        //variables: Map
        public GraphicsDeviceManager graphics;
        Texture2D spriteSheet;
        SpriteBatch spriteBatch;
        Board board;
        public int boardWidth, boardHeight;
        public const int tileSize = 32;
        public Point portal1;
        public Point portal2;

        //Variables: Characters
        public Player player;
        public bool ghostVulnerable = false;
        public List<Enemy> ghosts = new List<Enemy>();
        List<Point> portals = new List<Point>();
        public static Random RNG = new Random();

        public int balls = 0;

        //Propriedades
        /// <summary>
        /// Use esta propriedade para receber a spriteBatch
        /// </summary>
        public SpriteBatch SpriteBatch
        {
            get
            {
                return spriteBatch;
            }
        }

        /// <summary>
        /// Use esta propriedade para receber a spriteSheet
        /// </summary>
        public Texture2D SpriteSheet
        {
            get
            {
                return spriteSheet;
            }
        }

        /// <summary>
        /// Use esta propriedade para receber o board
        /// </summary>
        public Board Board
        {
            get
            {
                return board;
            }
        }


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteSheet = Content.Load<Texture2D>("pc");
            LoadLevel();
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            //If escaped is pressed, it exits the game
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            if (balls == -2)
            {
                player.Win();
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.GhostWhite);

            spriteBatch.Begin();
            for (int x = 0; x < boardWidth; x++)
            {
                for (int y = 0; y < boardHeight; y++)
                {
                    Rectangle rect = new Rectangle(x * tileSize, y * tileSize, tileSize, tileSize);

                    switch (Board.board[x, y])
                    {
                        case ' ':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(2 * 16, 2 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'W':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(15 * 16, 0, 16, 16),
                            Color.White
                            );
                            break;
                        case 'S':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(15 * 16, 4 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'A':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(14 * 16, 1 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'Z':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(14 * 16, 4 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'C':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(42 * 16, 4 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'E':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(42 * 16, 0, 16, 16),
                            Color.White
                            );
                            break;
                        case 'D':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(42 * 16, 1 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'Q':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(14 * 16, 0, 16, 16),
                            Color.White
                            );
                            break;
                        case 'P':
                            SpriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(1 * 16, 2 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'X':
                            SpriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(0, 2* 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'F':
                            SpriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(0, 2 * 16, 16, 16),
                            Color.White
                            );
                            break;
                        case 'O':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(15 * 16, 0, 16, 16),
                            Color.White
                            );
                            break;
                        case 'K':
                            spriteBatch.Draw(
                            spriteSheet,
                            rect,
                            new Rectangle(0, 1 * 16, 16, 16),
                            Color.White
                            );
                            break;

                    }
                }
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }


        void LoadLevel()
        {
            string[] file = File.ReadAllLines(Content.RootDirectory + "/level0.txt");
            boardWidth = file[0].Length;
            boardHeight = file.Length;

            board = new Board(this, boardWidth, boardHeight);
            Components.Add(board);

            

            for (int i = 0; i < boardHeight; i++)
            {
                for (int j = 0; j < boardWidth; j++)
                {
                    if (file[i][j] == 'G')
                    {
                        //ghosts
                        Enemy enemy = new Enemy(this, j, i);
                        ghosts.Add(enemy);
                        Components.Add(enemy);
                        Board.board[j, i] = ' ';
                    }
                    else if (file[i][j] == 'M')
                    {
                        //pacman
                        player = new Player(this, j, i);
                        Components.Add(player);
                        Board.board[j, i] = ' ';
                    }
                    else
                    {
                        Board.board[j, i] = file[i][j];

                        if (Board.board[j, i] == 'X')
                        {
                            portals.Add(new Point(j, i));
                        }

                        if (Board.board[j, i] == ' ' || Board.board [j,i] == 'K')
                        {
                            balls++;
                        }
                    }

                    
                }
            }

            //cria o portal1 (da esquerda)
            foreach (var portal in portals.Where(p => p.X == 0 && p.Y == 18))
            {
                portal1 = portal;
            }

            //cria o portal2 (da direita)
            foreach (var portal in portals.Where(p => p.X == 18 && p.Y == 18))
            {
                portal2 = portal;
            }

            //Set window size
            graphics.PreferredBackBufferWidth = boardWidth * tileSize;
            graphics.PreferredBackBufferHeight = (boardHeight + 1) * tileSize;
            graphics.ApplyChanges();
        }



    }
}
