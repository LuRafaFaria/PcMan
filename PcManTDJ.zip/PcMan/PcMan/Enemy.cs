﻿using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace PcMan
{
    public class Enemy: DrawableGameComponent
    {
        //variaveis
        Texture2D texture;
        SpriteBatch spriteBatch;
        Game1 game;
        Board board;
        public Point position, tPos, origin;
        enum GhostMode { Horizontal, Vertical, Scared, Dead }
        GhostMode ghostMode;
        int direction = 1;
        int patrolPosition = 0;
        int patrolLenght = 0;
        Dictionary<GhostMode, Vector2> spritePosition;
        int frame = 0;


        //constructor
        public Enemy(Game1 game, int x, int y) : base(game)
        {
            patrolLenght = 2 + Game1.RNG.Next(4);
            position.X = x * Game1.tileSize;
            position.Y = y * Game1.tileSize;
            origin = tPos = position;
            texture = game.SpriteSheet;
            spriteBatch = game.SpriteBatch;
            this.game = game;

            spritePosition = new Dictionary<GhostMode, Vector2>();
            spritePosition[GhostMode.Horizontal] = new Vector2(6, 4);
            spritePosition[GhostMode.Vertical] = new Vector2(6, 4);
            spritePosition[GhostMode.Scared] = new Vector2(4, 4);
            spritePosition[GhostMode.Dead] = new Vector2(4, 5);

        }

        public override void Update(GameTime gameTime)
        {


            if (position == tPos)
            {
                int xdistance = Math.Abs(position.X - game.player.position.X);
                int ydistance = Math.Abs(position.Y - game.player.position.Y);

                if (game.Board.board[position.X / Game1.tileSize + 1, position.Y / Game1.tileSize] == ' ' && xdistance > ydistance)
                {
                    if (xdistance < 0)
                    {
                        ghostMode = GhostMode.Horizontal;
                        new Point(direction * Game1.tileSize, 0);
                    }

                    else if (xdistance > 0)
                    {
                        ghostMode = GhostMode.Horizontal;
                        new Point(-direction * Game1.tileSize, 0);
                    }
                }

                else if (game.Board.board[position.X / Game1.tileSize - 1, position.Y / Game1.tileSize] == ' ' && xdistance > ydistance)
                {
                    if (xdistance < 0)
                    {
                        ghostMode = GhostMode.Horizontal;
                        new Point(direction * Game1.tileSize, 0);
                    }

                    else if (xdistance > 0)
                    {
                        ghostMode = GhostMode.Horizontal;
                        new Point(-direction * Game1.tileSize, 0);
                    }
                }

                else if (game.Board.board[position.X / Game1.tileSize, position.Y / Game1.tileSize + 1] == ' ' && xdistance < ydistance)
                {
                    if (ydistance < 0)
                    {
                        ghostMode = GhostMode.Vertical;
                        new Point(0, direction * Game1.tileSize);
                    }

                    else if (ydistance > 0)
                    {
                        ghostMode = GhostMode.Vertical;
                        new Point(0, -direction * Game1.tileSize);
                    }
                }

                else if (game.Board.board[position.X / Game1.tileSize, position.Y / Game1.tileSize - 1] == ' ' && xdistance < ydistance)
                {
                    if (ydistance < 0)
                    {
                        ghostMode = GhostMode.Vertical;
                        new Point(0, direction * Game1.tileSize);
                    }

                    else if (ydistance > 0)
                    {
                        ghostMode = GhostMode.Vertical;
                        new Point(0, -direction * Game1.tileSize);
                    }
                }

                if (game.Board.board[tPos.X / Game1.tileSize,
                                     tPos.Y / Game1.tileSize] == ' ')
                {
                    //increment patrol position
                    patrolPosition += direction;
                }

            }

            else
            {
                Vector2 dir = (tPos - position).ToVector2();
                dir.Normalize();
                position += dir.ToPoint();
            }


            if (game.ghostVulnerable == false)
            {
                if (new Rectangle(position, new Point(Game1.tileSize)).Intersects(new Rectangle(game.player.position, new Point(Game1.tileSize))))
                {
                    game.player.Die();
                }
            }

            else if (game.ghostVulnerable == true)
            {
                ghostMode = GhostMode.Scared;
                frame++;
                if (frame > 1)
                {
                    frame = 0;
                }

                if (new Rectangle(position, new Point(Game1.tileSize)).Intersects(new Rectangle(game.player.position, new Point(Game1.tileSize))))
                {
                    ghostMode = GhostMode.Dead;
                    
                }

            }
        }

        


        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(texture,
                new Rectangle(position.X, position.Y, Game1.tileSize, Game1.tileSize),
                new Rectangle(((spritePosition[ghostMode] + Vector2.UnitX * frame) * 16).ToPoint(), new Point(16, 16)),
                Color.White
            );
            
            spriteBatch.End();
            base.Draw(gameTime);

        }


    }
}
