﻿using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace PcMan
{
    public class Board: DrawableGameComponent
    {
        //variaveis
        public char[,] board;
        public int Height, Width;


        //construtor
        public Board(Game1 game, int width, int height) : base(game)
        {
            Height = height;
            Width = width;
            board = new char[width, height];

        }
    }
}
