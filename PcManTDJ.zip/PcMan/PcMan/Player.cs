﻿using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System;


namespace PcMan
{
    public class Player : DrawableGameComponent
    {
        public Point position;
        Point origin;
        Texture2D texture;
        SpriteBatch spriteBatch;
        Board board;
        Game1 game;
        SpriteFont arial;

        enum Direction { Up, Down, Right, Left }
        Dictionary<Direction, Vector2> spritePosition;
        Direction direction = Direction.Down; //Starting direction
        int frame = 0;
        Point tPos;
        public int lives = 3;
        int score = 0;
        bool winner = false;
        bool dead = false;

        public Player(Game1 game, int x, int y) : base(game)
        {
            position.Y = y * Game1.tileSize;
            position.X = x * Game1.tileSize;
            origin = tPos = position;

            texture = game.SpriteSheet;
            spriteBatch = game.SpriteBatch;
            board = game.Board;
            this.game = game;

            spritePosition = new Dictionary<Direction, Vector2>();
            spritePosition[Direction.Up] = new Vector2(12, 2);
            spritePosition[Direction.Down] = new Vector2(12, 3);
            spritePosition[Direction.Left] = new Vector2(12, 0);
            spritePosition[Direction.Right] = new Vector2(12, 1);

            arial = game.Content.Load<SpriteFont>("arial15");

        }

        public override void Update(GameTime gameTime)
        {


            if (tPos == position)
            {
                frame = 0;
                

                KeyboardState state = Keyboard.GetState();

                bool keyPressed = false;
                if (state.IsKeyDown(Keys.Up))
                {
                    direction = Direction.Up;
                    keyPressed = true;
                }
                if (state.IsKeyDown(Keys.Down))
                {
                    direction = Direction.Down;
                    keyPressed = true;
                }
                if (state.IsKeyDown(Keys.Right))
                {
                    direction = Direction.Right;
                    keyPressed = true;
                }
                if (state.IsKeyDown(Keys.Left))
                {
                    direction = Direction.Left;
                    keyPressed = true;
                }

                if (keyPressed)
                {
                    switch (direction)
                    {
                        case Direction.Up:
                            tPos.Y -= Game1.tileSize;
                            break;
                        case Direction.Down:
                            tPos.Y += Game1.tileSize;
                            break;
                        case Direction.Right:
                            tPos.X += Game1.tileSize;
                            break;
                        case Direction.Left:
                            tPos.X -= Game1.tileSize;
                            break;
                    }


                    switch (board.board[tPos.X / Game1.tileSize,
                                    tPos.Y / Game1.tileSize])
                    {
                        case 'Q':
                        case 'A':
                        case 'W':
                        case 'S':
                        case 'E':
                        case 'D':
                        case 'Z':
                        case 'C':
                        case 'P':
                        case 'O':
                            tPos = position;
                            break;
                        case ' ':
                            board.board[tPos.X / Game1.tileSize,
                                    tPos.Y / Game1.tileSize] = 'F'; //"come" as bolas amarelas e substitui pela tile preta
                            game.balls--;
                            score += 25;
                            break;
                        case 'K':
                            board.board[tPos.X / Game1.tileSize,
                                    tPos.Y / Game1.tileSize] = 'F';
                            game.balls--;
                            score += 100;
                            game.ghostVulnerable = true;
                            break;
                        case 'X':
                            //se passar no portal1 (esquerda) vai para o portal à direita
                            //(1 celula a esquerda para não ficar preso no portal)
                            if (game.portal1 == position)
                            {
                                position = game.portal2 + new Point(-1, 0);
                            }

                            //se passar no portal2 (direita) vai para o portal à esquerda
                            //(1 celula a direita para não ficar preso no portal)

                            else if (game.portal2 == position)
                            {
                                position = game.portal1 + new Point(1, 0);
                            }
                            break;
                    }

                }
            }
            else
            {
                //TODO: Resolver o problema de só andar uma celula
                //possiveis soluções: while pos == ' ' count++, tPos*count?...
                Vector2 dist = (tPos.ToVector2() - position.ToVector2());
                dist.Normalize();
                position = (position.ToVector2() + dist * 2).ToPoint();

                //
                if ((position.X + position.Y) % 8 == 0)
                {
                    frame++;
                }    
                if (frame > 1) 
                {
                    frame = 0; //repete frame 0 e 1
                }

            }


        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture,
                new Rectangle(position, new Point(Game1.tileSize)),
                new Rectangle(((spritePosition[direction] + Vector2.UnitX * frame) * 16).ToPoint(), new Point(16, 16)),
                Color.White
            );

            spriteBatch.DrawString(arial, $"Lives: {lives}", new Vector2(5, 3 + game.Board.Height * Game1.tileSize), Color.Black);
            spriteBatch.DrawString(arial, $"Score: {score}", new Vector2(495, 3 + game.Board.Height * Game1.tileSize), Color.Black);

            if (dead)
            {
                string gameover = "GAME OVER";
                Vector2 messageSize= arial.MeasureString(gameover);
                Vector2 screenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                 game.graphics.PreferredBackBufferHeight);
                Vector2 textPos = (screenSize - messageSize) / 2f;
                spriteBatch.DrawString(arial, gameover, textPos, Color.LightGoldenrodYellow);
            }

            if (winner)
            {
                string youwon = "YOU WON";
                Vector2 messageSize = arial.MeasureString(youwon);
                Vector2 screenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                 game.graphics.PreferredBackBufferHeight);
                Vector2 textPos = (screenSize - messageSize) / 2f;
                spriteBatch.DrawString(arial, youwon, textPos, Color.LightGoldenrodYellow);
            }


            spriteBatch.End();
        }

        public void Die()
        {
            lives--;
            position = tPos = origin;

            if (lives <= 0)
            {
                dead = true;
                //desativa os componentes
                foreach (DrawableGameComponent comp in game.Components)
                {
                    comp.Enabled = false;
                }
            }


        }

        public void Win()
        {
            winner = true;

            foreach (GameComponent component in game.Components)
            {
                component.Enabled = false;
            }
        }
    }
}
