TODO:

1-Descrição da implementação

2-Decisões tomadas

3-Instruções do jogo