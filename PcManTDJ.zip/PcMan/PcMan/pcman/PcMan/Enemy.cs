﻿using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Audio;

namespace PcMan
{
    public class Enemy : DrawableGameComponent
    {


        //variaveis
        Texture2D texture;
        SpriteBatch spriteBatch;
        Game1 game;
        Board board;
        public Point pos, tPos, origin;
        public enum GhostMode { Alive, Scared, Dead }
        enum Orientation { Horizontal, Vertical}
        enum Xaxis { Left, Right}
        Xaxis xaxis;
        enum Yaxis { Up, Down}
        Yaxis yaxis;
        Orientation orientation;
        public GhostMode ghostMode;
        int direction = 1;
        Dictionary<GhostMode, Vector2> spritePosition;
        int frame = 0;
        float vulnerableTime = 10f;
        float deadTime = 5f;
        bool dead = false;
        SoundEffect eatGhostSound;

        //constructor
        public Enemy(Game1 game, int x, int y) : base(game)
        {
            orientation = Game1.RNG.Next(2) > 1 ? Orientation.Horizontal : Orientation.Vertical;
            xaxis = Game1.RNG.Next(2) > 1 ? Xaxis.Left : Xaxis.Right;
            yaxis = Game1.RNG.Next(2) > 1 ? Yaxis.Down : Yaxis.Up;
            pos.X = x * Game1.tileSize;
            pos.Y = y * Game1.tileSize;
            origin = tPos = pos;
            texture = game.SpriteSheet;
            spriteBatch = game.SpriteBatch;
            this.game = game;

            spritePosition = new Dictionary<GhostMode, Vector2>();
            spritePosition[GhostMode.Alive] = new Vector2(6, 4);
            spritePosition[GhostMode.Scared] = new Vector2(4, 4);
            spritePosition[GhostMode.Dead] = new Vector2(4, 5);

            eatGhostSound = game.Content.Load<SoundEffect>("pacman_eatghost");
        }

        public override void Update(GameTime gameTime)
        {


            int xdistance = pos.X - game.player.position.X;
            int ydistance = pos.Y - game.player.position.Y;

            if (tPos == pos)
            {
                if (game.ghostVulnerable == false)
                {

                    if (Math.Abs(xdistance) >= Math.Abs(ydistance))
                    {

                        //player está a direita e fantasma pode andar para a direita
                        if (xdistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == ' ' ||
                                              game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'F' ||
                                              game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'K' ||
                                              game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'O'))
                        {
                            //anda para a direita
                            tPos += new Point(direction * Game1.tileSize, 0);
                        }

                        //player está a esquerda e fantasma pode andar para a esquerda
                        else if (xdistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'O'))
                             {
                                 //fantasma anda para a esquerda
                                 tPos += new Point(-direction * Game1.tileSize, 0);
                             }

                        //player está a esquerda ou direita mas fantasma não pode andar para nem para a direita nem para esquerda
                        else if ((xdistance < 0 || xdistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O')
                             {

                                 //player está em baixo e fantasma consegue andar para baixo
                                 if (ydistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == ' ' ||
                                                  game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'F' ||
                                                  game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'K' ||
                                                  game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'O'))
                                 {
                                     tPos += new Point(0, direction * Game1.tileSize);
                                 }

                                 //player está em cima e fantasma pode andar para cima
                                 else if (ydistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == ' ' ||
                                      game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'F' ||
                                      game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'K' ||
                                      game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'O'))
                                      {
                                          tPos += new Point(0, -direction * Game1.tileSize);
                                      }
                             }

                        //Player está a direita, fantasma não pode ir para a direita
                        else if ((ydistance == 0 & xdistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O')
                                                   )
                             {
                                 //RANDOM: Player pode ir para cima ou baixo
                                 tPos += yaxis == Yaxis.Up
                                               ? new Point(0, -direction * Game1.tileSize)
                                               : new Point(0, direction * Game1.tileSize);
                             }

                        //Player está a esquerda, fantasma não pode ir para a esquerda
                        else if ((ydistance == 0 & xdistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O')
                                                   )
                             {
                                 //RANDOM: Player pode ir para cima ou baixo
                                 tPos += yaxis == Yaxis.Up
                                               ? new Point(0, -direction * Game1.tileSize)
                                               : new Point(0, direction * Game1.tileSize);
                             }


                        //player está à direita em baixo, mas fantasma não pode andar nem para a direita nem para baixo
                        else if ((xdistance < 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                        {
                            //RANDOM: Fantasma ou anda para a esquerda ou para cima
                            tPos += orientation == Orientation.Horizontal
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                        }

                        //player está à esquerda em baixo, mas fantasma não pode andar nem para a esquerda nem para baixo
                        else if ((xdistance > 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                        {
                            //RANDOM: Fantasma ou anda para a direita ou para cima
                            tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                        }

                        //player está à esquerda em cima, mas fantasma não pode andar nem para a esquerda nem para cima
                        else if ((xdistance > 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                        {
                            //RANDOM: Fantasma ou anda para a direita ou para baixo
                            tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, direction * Game1.tileSize);
                        }

                        //Player está à direita em cima, fantasma não pode andar nem para a direita nem para cima
                        else if ((xdistance < 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                        {
                            //RANDOM: Fantasma anda para a esquerda ou para baixo
                            tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                        }

                    }

                    else if (Math.Abs(xdistance) < Math.Abs(ydistance))
                    {
                        //Player está em baixo e fantasma consegue andar para baixo
                        if (ydistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == ' ' ||
                        game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'F' ||
                        game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'K' ||
                        game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'O'))
                        {
                            tPos += new Point(0, direction * Game1.tileSize);
                        }

                        //Player está em cima e fantasma consegue andar para cima
                        else if (ydistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'O'))
                             {
                                 tPos += new Point(0, -direction * Game1.tileSize);
                             }

                        //PLayer está em baixo ou cima e fantasma não pode andar nem para baixo nem para cima
                        else if ((ydistance < 0 | ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O') &
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O')
                             {
                                 //Player está à direita e fantasma pode andar para a direita
                                 if (xdistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == ' ' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'F' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'K' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'O'))
                                 { 
                                     tPos += new Point(direction * Game1.tileSize, 0);
                                 }

                                 //Player está à esquerda e fantasma pode andar para a esquerda
                                 else if (xdistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == ' ' ||
                                                            game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'F' ||
                                                            game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'K' ||
                                                            game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'O'))
                                      {
                                          tPos += new Point(-direction * Game1.tileSize, 0);
                                      }
                             }

                        //Player está em baixo, fantasma não pode ir para baixo
                        else if (xdistance == 0 & ydistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O')
                                                   )
                             {
                                 //RANDOM: Player pode ir para a esquerda ou direita
                                 tPos += xaxis == Xaxis.Left
                                           ? new Point(-direction * Game1.tileSize, 0)
                                           : new Point(direction * Game1.tileSize, 0);
                             }


                        //Player está em cima, fantasma não pode ir para cima
                        else if (xdistance == 0 & ydistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O')
                                                   )
                             {
                                 //RANDOM: Player pode ir para a esquerda ou direita
                                  tPos += xaxis == Xaxis.Left
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(direction * Game1.tileSize, 0);
                             }




                        //player está à direita e em baixo, mas fantasma não pode andar para a direita ou para baixo
                        else if ((xdistance < 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                             {
                            //RANDOM: Fantasma ou anda para a esquerda ou para cima
                            tPos += orientation == Orientation.Horizontal
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                        }

                        //player está à esquerda em baixo, mas fantasma não pode andar nem para a esquerda nem para baixo
                        else if ((xdistance > 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                             {
                                 //RANDOM: Fantasma ou anda para a direita ou para cima
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                             }

                        //player está à esquerda em cima, mas fantasma não pode andar nem para a esquerda nem para cima
                        else if ((xdistance > 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                        {
                            //RANDOM: Fantasma ou anda para a direita ou para baixo
                            tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, direction * Game1.tileSize);
                        }

                        //player está à direita em cima, mas fantasma não pode andar nem para a direita nem para cima
                        else if ((xdistance < 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                             {   
                                 //RANDOM: Fantasma ou anda para a esquerda ou para baixo
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                             }


                    }

                }

                //Fantasma Vulneravel (FOGE DO PACMAN)
                else if (game.ghostVulnerable == true)
                {
                    if (Math.Abs(xdistance) >= Math.Abs(ydistance))
                    {


                        //Player está à direita e fantasma pode andar para a esquerda
                        if (xdistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == ' ' ||
                        game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'F' ||
                        game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'K' ||
                        game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'O'))
                        {
                            tPos += new Point(-direction * Game1.tileSize, 0);
                        }

                        //Player está à esquerda e fantasma pode andar para a direita
                        else if (xdistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == ' ' ||
                                  game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'F' ||
                                  game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'K' ||
                                  game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'O'))
                             {
                                 tPos += new Point(direction * Game1.tileSize, 0);
                             }

                        //Player está à esquerda ou direita, mas fantasma não pode andar para a esquerda ou direita
                        else if ((xdistance < 0 | xdistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O')
                             { 
                                 //Player está em baixo e fantasma pode andar para cima
                                 if (ydistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == ' ' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'F' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'K' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'O'))
                                 {
                                     tPos += new Point(0, -direction * Game1.tileSize);
                                 }

                                 //Player está em cima e fantasma pode andar para baixo
                                 else if (ydistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == ' ' ||
                                                            game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'F' ||
                                                            game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'K' ||
                                                            game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'O'))
                                      {  
                                          tPos += new Point(0, direction * Game1.tileSize);
                                      }
                             }

                        //Player está à direita, fantasma não pode ir para a esquerda
                        else if (ydistance == 0 & xdistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O')
                                                   )
                             {
                                 //RANDOM: Fantasma pode ir para cima ou baixo
                                 tPos += yaxis == Yaxis.Up
                                               ? new Point(0, -direction * Game1.tileSize)
                                               : new Point(0, direction * Game1.tileSize);
                             }

                        //Player está à esquerda, fantasma não pode ir para a direita
                        else if (ydistance == 0 & xdistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O')
                                                   )
                             {
                                 //RANDOM: Fantasma pode ir para cima ou baixo
                                 tPos += yaxis == Yaxis.Up
                                               ? new Point(0, -direction * Game1.tileSize)
                                               : new Point(0, direction * Game1.tileSize);
                             }


                        //Player está à direita em baixo, fantasma não pode andar para a esquerda ou para cima
                        else if ((xdistance < 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                             {
                                 //RANDOM: Fantasma anda para a direita ou para baixo
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, direction * Game1.tileSize);
                             }

                        //Player está a esquerda e em baixo, fantasma não pode andar nem para a direita nem para cima
                        else if ((xdistance > 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                             {
                                 //RANDOM: Fantasma ou anda para a esquerda ou para baixo
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(0, direction * Game1.tileSize);
                             }

                        //Player está a esquerda em cima, mas fantasma não consegue ir para a direita ou para baixo
                        else if ((xdistance > 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                             {
                                 //RANDOM: Fantasma anda para a esquerda ou para cima
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                             }

                        //Player está a direita em cima, fantasma não pode ir para a esquerda ou para baixo
                        else if ((xdistance < 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                             {
                                 //RANDOM: Fantasma ou anda para direita ou para cima
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                             }

                    }

                    else if (Math.Abs(xdistance) < Math.Abs(ydistance))
                    {
                        //Player está em baixo, fantasma pode ir para cima
                        if (ydistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == ' ' ||
                                              game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'F' ||
                                              game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'K' ||
                                              game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] == 'O'))
                        {
                            tPos += new Point(0, -direction * Game1.tileSize);
                        }

                        //Player está em cima, fantasma pode ir para baixo
                        else if (ydistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] == 'O'))
                             {
                                 tPos += new Point(0, direction * Game1.tileSize);
                             }
                        //Player está em cima ou baixo, mas fantasma não pode ir para cima nem para baixo
                        else if ((ydistance < 0 | ydistance > 0) & ((game.Board.board[(pos.X) / Game1.tileSize , pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O') &
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                                                   
                             {
                                 //Player está a direita e fantasma pode ir para a esquerda
                                 if (xdistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == ' ' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'F' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'K' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] == 'O'))
                                 {
                                     tPos += new Point(-direction * Game1.tileSize, 0);
                                 }

                                 //Player está à esquerda, fantasma pode ir para a direita
                                 else if (xdistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == ' ' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'F' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'K' ||
                                                       game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] == 'O'))
                                      {
                                          tPos += new Point(direction * Game1.tileSize, 0);
                                      }
                             }

                        //Player está em baixo, fantasma não pode ir para cima
                        else if (xdistance == 0 & ydistance < 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O')
                                                   )
                             {
                                 //RANDOM: Fantasma pode ir para a esquerda ou direita
                                 tPos += xaxis == Xaxis.Left
                                      ? new Point(-direction * Game1.tileSize, 0)
                                      : new Point(direction * Game1.tileSize, 0);
                             }

                        //Player está em cima, fantasma não pode ir para baixo
                        else if (xdistance == 0 & ydistance > 0 & (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O')
                                                   )
                             {
                                 //RANDOM: Fantasma pode ir para a esquerda ou direita
                                 tPos += xaxis == Xaxis.Left
                                               ? new Point(-direction * Game1.tileSize, 0)
                                               : new Point(direction * Game1.tileSize, 0);
                             }     


                        //Player está à direita em baixo, fantasma não consegue ir para a esquerda ou para cima
                        else if ((xdistance < 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                             {
                                 //RANDOM: Fantasma pode ir para a direita ou para baixo
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, direction * Game1.tileSize);
                             }

                        //Player está à esquerda em baixo, fantasmas não pode ir nem para a direita nem para cima
                        else if ((xdistance > 0 & ydistance < 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize - 1] != 'O'))
                             {
                                 //RANDOM: Fantasma pode ir para a esquerda ou para baixo
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(0, direction * Game1.tileSize);
                             }

                        //Player está a esquerda e em cima, fantasma não pode ir nem para a direita nem para baixo
                        else if ((xdistance > 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize + 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                             {
                                 //RANDOM: Fantasma ou vai para a esquerda ou para cima
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(-direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                             }

                        //Player está à direita em cima, fantasma não pode ir nem para a esquerda nem para baixo
                        else if ((xdistance < 0 & ydistance > 0) & (game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize - 1, pos.Y / Game1.tileSize] != 'O') &
                                                   (game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != ' ' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'F' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'K' ||
                                                   game.Board.board[(pos.X) / Game1.tileSize, pos.Y / Game1.tileSize + 1] != 'O'))
                             {
                                 //RANDOM: Fantasma pode ir para a direita ou para cima
                                 tPos += orientation == Orientation.Horizontal
                                                ? new Point(direction * Game1.tileSize, 0)
                                                : new Point(0, -direction * Game1.tileSize);
                             }
                    }
                }
            }

            else
            {
                Vector2 dir = (tPos - pos).ToVector2();
                dir.Normalize();
                pos += dir.ToPoint();
            }


            if (game.ghostVulnerable == false)
            {
                if (new Rectangle(pos, new Point(Game1.tileSize)).Intersects(new Rectangle(game.player.position, new Point(Game1.tileSize))))
                {
                    game.player.Die();
                }
            }

            else if (game.ghostVulnerable == true)
            {
                vulnerableTime -= gameTime.DeltaTime();
               

                if (vulnerableTime <= 0)
                {
                    foreach (var ghost in game.ghosts)
                    {
                        ghost.ghostMode = GhostMode.Alive;
                        game.ghostVulnerable = false;
                        ghost.vulnerableTime = 10f;
                    }
                    
                }

                else if (vulnerableTime > 0)
                {
                    ghostMode = GhostMode.Scared;
                    frame++;
                    if (frame > 1)
                    {
                        frame = 0;
                    }


                    if ((game.player.position.X / Game1.tileSize == pos.X / Game1.tileSize) && (game.player.position.Y / Game1.tileSize == pos.Y / Game1.tileSize))
                    {
                        eatGhostSound.Play();
                        game.player.score += 250;
                        dead = true;
                        
                    }

                    if (dead == true)
                    {
                        deadTime -= gameTime.DeltaTime();

                        foreach (var ghost in game.ghosts)
                        {
                            ghost.ghostMode = GhostMode.Dead;
                            
                            
                        }


                        if (deadTime > 0)
                        {
                            tPos = pos = origin;
                        }

                        else if (deadTime < 0)
                        {
                            dead = false;
                            ghostMode = GhostMode.Alive;
                            frame = 0;
                        }

                    }

                }
            }
        }




        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            spriteBatch.Draw(texture,
                new Rectangle(pos.X, pos.Y, Game1.tileSize, Game1.tileSize),
                new Rectangle(((spritePosition[ghostMode] + Vector2.UnitX * frame) * 16).ToPoint(), new Point(16, 16)),
                Color.White
            );

            spriteBatch.End();
            base.Draw(gameTime);

        }


    }
}
